package com.exemplo.legendaryblades;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Foice: quebra muito mais rapido tudo que a enxada quebra (folhas, feno, musgo, esponja...). Nao ara a terra. */
public class ModScytheItem extends ModSwordItem {

    public ModScytheItem(String id, Tier tier, float attackSpeed, Rarity rarity,
                         boolean foil, boolean fireproof, HitEffect effect) {
        super(id, tier, attackSpeed, rarity, foil, fireproof, effect);
    }

    @Override
    public float getDestroySpeed(ItemStack stack, BlockState state) {
        if (state.is(BlockTags.MINEABLE_WITH_HOE) || state.is(BlockTags.LEAVES) || state.is(Blocks.HAY_BLOCK)) {
            return 60.0F;
        }
        return super.getDestroySpeed(stack, state);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        tooltip.add(Component.translatable("tooltip." + LegendaryBlades.MODID + ".scythe_speed")
                .withStyle(ChatFormatting.GRAY));
    }
}
