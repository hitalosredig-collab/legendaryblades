package com.exemplo.legendaryblades;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, LegendaryBlades.MODID);

    // id, tier(durabilidade, dano total, encantamento, reparo), velocidade, raridade, brilho, anti-fogo, efeito
    public static final RegistryObject<Item> EMERALD_KATANA = ITEMS.register("emerald_katana",
            () -> new ModSwordItem("emerald_katana",
                    new SwordTier(1700, 13F, 22, () -> Ingredient.of(Items.EMERALD)),
                    -1.4F, Rarity.UNCOMMON, false, false, SwordEffects::emerald));

    public static final RegistryObject<Item> AMETHYST_KATANA = ITEMS.register("amethyst_katana",
            () -> new ModSwordItem("amethyst_katana",
                    new SwordTier(1500, 12F, 22, () -> Ingredient.of(Items.AMETHYST_SHARD)),
                    -1.4F, Rarity.RARE, false, false, SwordEffects::amethyst));

    public static final RegistryObject<Item> FROST_BLADE = ITEMS.register("frost_blade",
            () -> new ModSwordItem("frost_blade",
                    new SwordTier(980, 14F, 20, () -> Ingredient.of(Items.BLUE_ICE)),
                    -2.6F, Rarity.RARE, false, false, SwordEffects::frost));

    public static final RegistryObject<Item> TWILIGHT_BLADE = ITEMS.register("twilight_blade",
            () -> new ModSwordItem("twilight_blade",
                    new SwordTier(2500, 15F, 18, () -> Ingredient.of(Items.DIAMOND)),
                    -2.6F, Rarity.EPIC, true, true, SwordEffects::twilight));

    public static final RegistryObject<Item> THUNDER_BLADE = ITEMS.register("thunder_blade",
            () -> new ModSwordItem("thunder_blade",
                    new SwordTier(2200, 16F, 20, () -> Ingredient.of(Items.DIAMOND)),
                    -2.6F, Rarity.EPIC, true, false, SwordEffects::thunder));

    // --- Lendarias: mais de 50 de dano, receita muito dificil ---
    public static final RegistryObject<Item> CELESTIAL_BLADE = ITEMS.register("celestial_blade",
            () -> new ModSwordItem("celestial_blade",
                    new SwordTier(4000, 52F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -3.0F, Rarity.EPIC, true, true, SwordEffects::celestial));

    public static final RegistryObject<Item> VOID_BLADE = ITEMS.register("void_blade",
            () -> new ModSwordItem("void_blade",
                    new SwordTier(6000, 66F, 25, () -> Ingredient.of(Items.NETHER_STAR)),
                    -3.2F, Rarity.EPIC, true, true, SwordEffects::voidBlade));

    // --- A espada lendaria principal ---
    public static final RegistryObject<Item> LEGENDARY_SWORD = ITEMS.register("legendary_sword",
            () -> new ModSwordItem("legendary_sword",
                    new SwordTier(5000, 130F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -3.3F, Rarity.EPIC, true, true, SwordEffects::legendary));

    // --- Espadas "estilo vanilla" (sem efeito especial) ---
    public static final RegistryObject<Item> COPPER_SWORD = ITEMS.register("copper_sword",
            () -> new ModSwordItem("copper_sword",
                    new SwordTier(250, 6F, 12, () -> Ingredient.of(Items.COPPER_INGOT)),
                    -2.4F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> EMERALD_SWORD = ITEMS.register("emerald_sword",
            () -> new ModSwordItem("emerald_sword",
                    new SwordTier(1200, 8F, 20, () -> Ingredient.of(Items.EMERALD)),
                    -2.4F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> OBSIDIAN_SWORD = ITEMS.register("obsidian_sword",
            () -> new ModSwordItem("obsidian_sword",
                    new SwordTier(4200, 35F, 10, () -> Ingredient.of(Items.OBSIDIAN)),
                    -2.8F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> QUARTZ_SWORD = ITEMS.register("quartz_sword",
            () -> new ModSwordItem("quartz_sword",
                    new SwordTier(800, 7F, 18, () -> Ingredient.of(Items.QUARTZ)),
                    -2.4F, Rarity.COMMON, false, false, null));

    // --- Montantes: espadas longas de cada material, com muito mais dano ---
    public static final RegistryObject<Item> WOODEN_GREATSWORD = ITEMS.register("wooden_greatsword",
            () -> new ModSwordItem("wooden_greatsword",
                    new SwordTier(150, 9F, 15, () -> Ingredient.of(Items.OAK_PLANKS)),
                    -3.0F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> STONE_GREATSWORD = ITEMS.register("stone_greatsword",
            () -> new ModSwordItem("stone_greatsword",
                    new SwordTier(320, 13F, 5, () -> Ingredient.of(Items.COBBLESTONE)),
                    -3.0F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> IRON_GREATSWORD = ITEMS.register("iron_greatsword",
            () -> new ModSwordItem("iron_greatsword",
                    new SwordTier(600, 18F, 14, () -> Ingredient.of(Items.IRON_INGOT)),
                    -3.0F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> GOLDEN_GREATSWORD = ITEMS.register("golden_greatsword",
            () -> new ModSwordItem("golden_greatsword",
                    new SwordTier(140, 14F, 30, () -> Ingredient.of(Items.GOLD_INGOT)),
                    -3.0F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> DIAMOND_GREATSWORD = ITEMS.register("diamond_greatsword",
            () -> new ModSwordItem("diamond_greatsword",
                    new SwordTier(2400, 26F, 10, () -> Ingredient.of(Items.DIAMOND)),
                    -3.1F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> NETHERITE_GREATSWORD = ITEMS.register("netherite_greatsword",
            () -> new ModSwordItem("netherite_greatsword",
                    new SwordTier(3200, 38F, 15, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -3.2F, Rarity.EPIC, true, true, null));

    // --- Katanas, foices, adagas e rapieiras ---
    public static final RegistryObject<Item> IRON_KATANA = ITEMS.register("iron_katana",
            () -> new ModSwordItem("iron_katana",
                    new SwordTier(900, 11F, 14, () -> Ingredient.of(Items.IRON_INGOT)),
                    -1.4F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> DIAMOND_KATANA = ITEMS.register("diamond_katana",
            () -> new ModSwordItem("diamond_katana",
                    new SwordTier(2000, 15F, 10, () -> Ingredient.of(Items.DIAMOND)),
                    -1.4F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> NETHERITE_KATANA = ITEMS.register("netherite_katana",
            () -> new ModSwordItem("netherite_katana",
                    new SwordTier(3000, 20F, 15, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -1.4F, Rarity.EPIC, true, true, null));

    public static final RegistryObject<Item> FIRE_KATANA = ITEMS.register("fire_katana",
            () -> new ModSwordItem("fire_katana",
                    new SwordTier(1800, 17F, 18, () -> Ingredient.of(Items.BLAZE_POWDER)),
                    -1.4F, Rarity.RARE, true, true, SwordEffects::twilight));

    public static final RegistryObject<Item> FROST_KATANA = ITEMS.register("frost_katana",
            () -> new ModSwordItem("frost_katana",
                    new SwordTier(1500, 15F, 18, () -> Ingredient.of(Items.BLUE_ICE)),
                    -1.4F, Rarity.RARE, false, false, SwordEffects::frost));

    public static final RegistryObject<Item> SHADOW_KATANA = ITEMS.register("shadow_katana",
            () -> new ModSwordItem("shadow_katana",
                    new SwordTier(2800, 28F, 22, () -> Ingredient.of(Items.ECHO_SHARD)),
                    -1.4F, Rarity.EPIC, true, true, SwordEffects::voidBlade));

    public static final RegistryObject<Item> IRON_SCYTHE = ITEMS.register("iron_scythe",
            () -> new ModScytheItem("iron_scythe",
                    new SwordTier(700, 16F, 14, () -> Ingredient.of(Items.IRON_INGOT)),
                    -3.0F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> GOLDEN_SCYTHE = ITEMS.register("golden_scythe",
            () -> new ModScytheItem("golden_scythe",
                    new SwordTier(160, 17F, 30, () -> Ingredient.of(Items.GOLD_INGOT)),
                    -3.0F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> EMERALD_SCYTHE = ITEMS.register("emerald_scythe",
            () -> new ModScytheItem("emerald_scythe",
                    new SwordTier(1400, 20F, 20, () -> Ingredient.of(Items.EMERALD)),
                    -3.0F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> DIAMOND_SCYTHE = ITEMS.register("diamond_scythe",
            () -> new ModScytheItem("diamond_scythe",
                    new SwordTier(2200, 24F, 10, () -> Ingredient.of(Items.DIAMOND)),
                    -3.0F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> NETHERITE_SCYTHE = ITEMS.register("netherite_scythe",
            () -> new ModScytheItem("netherite_scythe",
                    new SwordTier(3100, 34F, 15, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -3.1F, Rarity.EPIC, true, true, null));

    public static final RegistryObject<Item> REAPER_SCYTHE = ITEMS.register("reaper_scythe",
            () -> new ModScytheItem("reaper_scythe",
                    new SwordTier(4500, 55F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -3.2F, Rarity.EPIC, true, true, SwordEffects::reaper));

    public static final RegistryObject<Item> IRON_DAGGER = ITEMS.register("iron_dagger",
            () -> new ModSwordItem("iron_dagger",
                    new SwordTier(300, 5F, 14, () -> Ingredient.of(Items.IRON_INGOT)),
                    -0.8F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> DIAMOND_DAGGER = ITEMS.register("diamond_dagger",
            () -> new ModSwordItem("diamond_dagger",
                    new SwordTier(900, 7F, 10, () -> Ingredient.of(Items.DIAMOND)),
                    -0.8F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> NETHERITE_DAGGER = ITEMS.register("netherite_dagger",
            () -> new ModSwordItem("netherite_dagger",
                    new SwordTier(1300, 9F, 15, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -0.8F, Rarity.EPIC, true, true, null));

    public static final RegistryObject<Item> POISON_DAGGER = ITEMS.register("poison_dagger",
            () -> new ModSwordItem("poison_dagger",
                    new SwordTier(600, 8F, 15, () -> Ingredient.of(Items.FERMENTED_SPIDER_EYE)),
                    -0.8F, Rarity.UNCOMMON, false, false, SwordEffects::poison));

    public static final RegistryObject<Item> IRON_RAPIER = ITEMS.register("iron_rapier",
            () -> new ModSwordItem("iron_rapier",
                    new SwordTier(700, 8F, 14, () -> Ingredient.of(Items.IRON_INGOT)),
                    -1.0F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> GOLDEN_RAPIER = ITEMS.register("golden_rapier",
            () -> new ModSwordItem("golden_rapier",
                    new SwordTier(120, 7F, 30, () -> Ingredient.of(Items.GOLD_INGOT)),
                    -1.0F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> DIAMOND_RAPIER = ITEMS.register("diamond_rapier",
            () -> new ModSwordItem("diamond_rapier",
                    new SwordTier(1800, 12F, 10, () -> Ingredient.of(Items.DIAMOND)),
                    -1.0F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> NETHERITE_RAPIER = ITEMS.register("netherite_rapier",
            () -> new ModSwordItem("netherite_rapier",
                    new SwordTier(2600, 16F, 15, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -1.0F, Rarity.EPIC, true, true, null));

    // --- Novos formatos de espada em cada material ---
    public static final RegistryObject<Item> WOODEN_SLIM_SWORD = ITEMS.register("wooden_slim_sword",
            () -> new ModSwordItem("wooden_slim_sword",
                    new SwordTier(53, 7F, 15, () -> Ingredient.of(Items.OAK_PLANKS)),
                    -2.1F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> STONE_SLIM_SWORD = ITEMS.register("stone_slim_sword",
            () -> new ModSwordItem("stone_slim_sword",
                    new SwordTier(118, 8F, 5, () -> Ingredient.of(Items.COBBLESTONE)),
                    -2.1F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> IRON_SLIM_SWORD = ITEMS.register("iron_slim_sword",
            () -> new ModSwordItem("iron_slim_sword",
                    new SwordTier(225, 9F, 14, () -> Ingredient.of(Items.IRON_INGOT)),
                    -2.1F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> GOLDEN_SLIM_SWORD = ITEMS.register("golden_slim_sword",
            () -> new ModSwordItem("golden_slim_sword",
                    new SwordTier(29, 7F, 22, () -> Ingredient.of(Items.GOLD_INGOT)),
                    -2.1F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> DIAMOND_SLIM_SWORD = ITEMS.register("diamond_slim_sword",
            () -> new ModSwordItem("diamond_slim_sword",
                    new SwordTier(1405, 10F, 10, () -> Ingredient.of(Items.DIAMOND)),
                    -2.1F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> NETHERITE_SLIM_SWORD = ITEMS.register("netherite_slim_sword",
            () -> new ModSwordItem("netherite_slim_sword",
                    new SwordTier(1828, 11F, 15, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -2.1F, Rarity.EPIC, true, true, null));

    public static final RegistryObject<Item> WOODEN_ANCIENT_SWORD = ITEMS.register("wooden_ancient_sword",
            () -> new ModSwordItem("wooden_ancient_sword",
                    new SwordTier(77, 8F, 15, () -> Ingredient.of(Items.OAK_PLANKS)),
                    -2.5F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> STONE_ANCIENT_SWORD = ITEMS.register("stone_ancient_sword",
            () -> new ModSwordItem("stone_ancient_sword",
                    new SwordTier(170, 9F, 5, () -> Ingredient.of(Items.COBBLESTONE)),
                    -2.5F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> IRON_ANCIENT_SWORD = ITEMS.register("iron_ancient_sword",
            () -> new ModSwordItem("iron_ancient_sword",
                    new SwordTier(325, 10F, 14, () -> Ingredient.of(Items.IRON_INGOT)),
                    -2.5F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> GOLDEN_ANCIENT_SWORD = ITEMS.register("golden_ancient_sword",
            () -> new ModSwordItem("golden_ancient_sword",
                    new SwordTier(42, 8F, 22, () -> Ingredient.of(Items.GOLD_INGOT)),
                    -2.5F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> DIAMOND_ANCIENT_SWORD = ITEMS.register("diamond_ancient_sword",
            () -> new ModSwordItem("diamond_ancient_sword",
                    new SwordTier(2029, 11F, 10, () -> Ingredient.of(Items.DIAMOND)),
                    -2.5F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> NETHERITE_ANCIENT_SWORD = ITEMS.register("netherite_ancient_sword",
            () -> new ModSwordItem("netherite_ancient_sword",
                    new SwordTier(2640, 12F, 15, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -2.5F, Rarity.EPIC, true, true, null));

    public static final RegistryObject<Item> WOODEN_SCIMITAR = ITEMS.register("wooden_scimitar",
            () -> new ModSwordItem("wooden_scimitar",
                    new SwordTier(65, 9F, 15, () -> Ingredient.of(Items.OAK_PLANKS)),
                    -2.4F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> STONE_SCIMITAR = ITEMS.register("stone_scimitar",
            () -> new ModSwordItem("stone_scimitar",
                    new SwordTier(144, 10F, 5, () -> Ingredient.of(Items.COBBLESTONE)),
                    -2.4F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> IRON_SCIMITAR = ITEMS.register("iron_scimitar",
            () -> new ModSwordItem("iron_scimitar",
                    new SwordTier(275, 11F, 14, () -> Ingredient.of(Items.IRON_INGOT)),
                    -2.4F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> GOLDEN_SCIMITAR = ITEMS.register("golden_scimitar",
            () -> new ModSwordItem("golden_scimitar",
                    new SwordTier(35, 9F, 22, () -> Ingredient.of(Items.GOLD_INGOT)),
                    -2.4F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> DIAMOND_SCIMITAR = ITEMS.register("diamond_scimitar",
            () -> new ModSwordItem("diamond_scimitar",
                    new SwordTier(1717, 12F, 10, () -> Ingredient.of(Items.DIAMOND)),
                    -2.4F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> NETHERITE_SCIMITAR = ITEMS.register("netherite_scimitar",
            () -> new ModSwordItem("netherite_scimitar",
                    new SwordTier(2234, 13F, 15, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -2.4F, Rarity.EPIC, true, true, null));

    public static final RegistryObject<Item> WOODEN_GLADIUS = ITEMS.register("wooden_gladius",
            () -> new ModSwordItem("wooden_gladius",
                    new SwordTier(71, 6F, 15, () -> Ingredient.of(Items.OAK_PLANKS)),
                    -1.6F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> STONE_GLADIUS = ITEMS.register("stone_gladius",
            () -> new ModSwordItem("stone_gladius",
                    new SwordTier(157, 7F, 5, () -> Ingredient.of(Items.COBBLESTONE)),
                    -1.6F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> IRON_GLADIUS = ITEMS.register("iron_gladius",
            () -> new ModSwordItem("iron_gladius",
                    new SwordTier(300, 8F, 14, () -> Ingredient.of(Items.IRON_INGOT)),
                    -1.6F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> GOLDEN_GLADIUS = ITEMS.register("golden_gladius",
            () -> new ModSwordItem("golden_gladius",
                    new SwordTier(38, 6F, 22, () -> Ingredient.of(Items.GOLD_INGOT)),
                    -1.6F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> DIAMOND_GLADIUS = ITEMS.register("diamond_gladius",
            () -> new ModSwordItem("diamond_gladius",
                    new SwordTier(1873, 9F, 10, () -> Ingredient.of(Items.DIAMOND)),
                    -1.6F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> NETHERITE_GLADIUS = ITEMS.register("netherite_gladius",
            () -> new ModSwordItem("netherite_gladius",
                    new SwordTier(2437, 10F, 15, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -1.6F, Rarity.EPIC, true, true, null));

    public static final RegistryObject<Item> WOODEN_SERRATED_SWORD = ITEMS.register("wooden_serrated_sword",
            () -> new ModSwordItem("wooden_serrated_sword",
                    new SwordTier(47, 11F, 15, () -> Ingredient.of(Items.OAK_PLANKS)),
                    -2.8F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> STONE_SERRATED_SWORD = ITEMS.register("stone_serrated_sword",
            () -> new ModSwordItem("stone_serrated_sword",
                    new SwordTier(105, 12F, 5, () -> Ingredient.of(Items.COBBLESTONE)),
                    -2.8F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> IRON_SERRATED_SWORD = ITEMS.register("iron_serrated_sword",
            () -> new ModSwordItem("iron_serrated_sword",
                    new SwordTier(200, 13F, 14, () -> Ingredient.of(Items.IRON_INGOT)),
                    -2.8F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> GOLDEN_SERRATED_SWORD = ITEMS.register("golden_serrated_sword",
            () -> new ModSwordItem("golden_serrated_sword",
                    new SwordTier(26, 11F, 22, () -> Ingredient.of(Items.GOLD_INGOT)),
                    -2.8F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> DIAMOND_SERRATED_SWORD = ITEMS.register("diamond_serrated_sword",
            () -> new ModSwordItem("diamond_serrated_sword",
                    new SwordTier(1249, 14F, 10, () -> Ingredient.of(Items.DIAMOND)),
                    -2.8F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> NETHERITE_SERRATED_SWORD = ITEMS.register("netherite_serrated_sword",
            () -> new ModSwordItem("netherite_serrated_sword",
                    new SwordTier(1625, 15F, 15, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -2.8F, Rarity.EPIC, true, true, null));

    // --- Completando todas as familias nos materiais basicos ---
    public static final RegistryObject<Item> WOODEN_KATANA = ITEMS.register("wooden_katana",
            () -> new ModSwordItem("wooden_katana",
                    new SwordTier(200, 7F, 15, () -> Ingredient.of(Items.OAK_PLANKS)),
                    -1.4F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> STONE_KATANA = ITEMS.register("stone_katana",
            () -> new ModSwordItem("stone_katana",
                    new SwordTier(450, 9F, 5, () -> Ingredient.of(Items.COBBLESTONE)),
                    -1.4F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> GOLDEN_KATANA = ITEMS.register("golden_katana",
            () -> new ModSwordItem("golden_katana",
                    new SwordTier(120, 10F, 30, () -> Ingredient.of(Items.GOLD_INGOT)),
                    -1.4F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> WOODEN_SCYTHE = ITEMS.register("wooden_scythe",
            () -> new ModScytheItem("wooden_scythe",
                    new SwordTier(180, 10F, 15, () -> Ingredient.of(Items.OAK_PLANKS)),
                    -3.0F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> STONE_SCYTHE = ITEMS.register("stone_scythe",
            () -> new ModScytheItem("stone_scythe",
                    new SwordTier(400, 13F, 5, () -> Ingredient.of(Items.COBBLESTONE)),
                    -3.0F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> WOODEN_DAGGER = ITEMS.register("wooden_dagger",
            () -> new ModSwordItem("wooden_dagger",
                    new SwordTier(90, 3F, 15, () -> Ingredient.of(Items.OAK_PLANKS)),
                    -0.8F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> STONE_DAGGER = ITEMS.register("stone_dagger",
            () -> new ModSwordItem("stone_dagger",
                    new SwordTier(200, 4F, 5, () -> Ingredient.of(Items.COBBLESTONE)),
                    -0.8F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> GOLDEN_DAGGER = ITEMS.register("golden_dagger",
            () -> new ModSwordItem("golden_dagger",
                    new SwordTier(80, 4F, 30, () -> Ingredient.of(Items.GOLD_INGOT)),
                    -0.8F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> WOODEN_RAPIER = ITEMS.register("wooden_rapier",
            () -> new ModSwordItem("wooden_rapier",
                    new SwordTier(120, 5F, 15, () -> Ingredient.of(Items.OAK_PLANKS)),
                    -1.0F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> STONE_RAPIER = ITEMS.register("stone_rapier",
            () -> new ModSwordItem("stone_rapier",
                    new SwordTier(260, 6F, 5, () -> Ingredient.of(Items.COBBLESTONE)),
                    -1.0F, Rarity.COMMON, false, false, null));

    // --- Uma arma lendaria para cada tipo ---
    public static final RegistryObject<Item> LUNAR_KATANA = ITEMS.register("lunar_katana",
            () -> new ModSwordItem("lunar_katana",
                    new SwordTier(6000, 62F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -1.4F, Rarity.EPIC, true, true, SwordEffects::lunar));

    public static final RegistryObject<Item> UMBRAL_DAGGER = ITEMS.register("umbral_dagger",
            () -> new ModSwordItem("umbral_dagger",
                    new SwordTier(5000, 34F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -0.8F, Rarity.EPIC, true, true, SwordEffects::umbral));

    public static final RegistryObject<Item> STORM_RAPIER = ITEMS.register("storm_rapier",
            () -> new ModSwordItem("storm_rapier",
                    new SwordTier(5000, 40F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -1.0F, Rarity.EPIC, true, true, SwordEffects::thunder));

    public static final RegistryObject<Item> FROSTBOUND_SLIM_SWORD = ITEMS.register("frostbound_slim_sword",
            () -> new ModSwordItem("frostbound_slim_sword",
                    new SwordTier(5500, 44F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -2.1F, Rarity.EPIC, true, true, SwordEffects::frost));

    public static final RegistryObject<Item> SOVEREIGN_ANCIENT_SWORD = ITEMS.register("sovereign_ancient_sword",
            () -> new ModSwordItem("sovereign_ancient_sword",
                    new SwordTier(7000, 58F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -2.5F, Rarity.EPIC, true, true, SwordEffects::sovereign));

    public static final RegistryObject<Item> INFERNO_SCIMITAR = ITEMS.register("inferno_scimitar",
            () -> new ModSwordItem("inferno_scimitar",
                    new SwordTier(6000, 52F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -2.4F, Rarity.EPIC, true, true, SwordEffects::inferno));

    public static final RegistryObject<Item> IMPERIAL_GLADIUS = ITEMS.register("imperial_gladius",
            () -> new ModSwordItem("imperial_gladius",
                    new SwordTier(5000, 30F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -1.6F, Rarity.EPIC, true, true, SwordEffects::imperial));

    public static final RegistryObject<Item> DRAGONFANG_SWORD = ITEMS.register("dragonfang_sword",
            () -> new ModSwordItem("dragonfang_sword",
                    new SwordTier(6500, 72F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -2.8F, Rarity.EPIC, true, true, SwordEffects::dragonfang));

    public static final RegistryObject<Item> TITAN_GREATSWORD = ITEMS.register("titan_greatsword",
            () -> new ModSwordItem("titan_greatsword",
                    new SwordTier(8000, 95F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -3.3F, Rarity.EPIC, true, true, SwordEffects::titan));
}
