package com.exemplo.legendaryblades;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;

public final class SwordEffects {
    private SwordEffects() {}

    private static void particles(LivingEntity target, ParticleOptions type, int count) {
        if (target.level() instanceof ServerLevel server) {
            server.sendParticles(type, target.getX(), target.getY(0.5D), target.getZ(),
                    count, 0.3D, 0.4D, 0.3D, 0.02D);
        }
    }

    public static void emerald(LivingEntity target, LivingEntity attacker) {
        attacker.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 0));
        particles(target, ParticleTypes.HAPPY_VILLAGER, 8);
    }

    public static void amethyst(LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 0));
        particles(target, ParticleTypes.WITCH, 10);
    }

    public static void frost(LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
        particles(target, ParticleTypes.SNOWFLAKE, 14);
    }

    public static void twilight(LivingEntity target, LivingEntity attacker) {
        target.setSecondsOnFire(4);
        particles(target, ParticleTypes.FLAME, 12);
    }

    public static void thunder(LivingEntity target, LivingEntity attacker) {
        if (target.level() instanceof ServerLevel server) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(server);
            if (bolt != null) {
                bolt.moveTo(target.getX(), target.getY(), target.getZ());
                bolt.setVisualOnly(true); // so o visual, nao incendeia o mapa
                server.addFreshEntity(bolt);
            }
        }
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 2));
    }

    public static void celestial(LivingEntity target, LivingEntity attacker) {
        target.setSecondsOnFire(6);
        attacker.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 1));
        particles(target, ParticleTypes.END_ROD, 16);
    }

    public static void voidBlade(LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
        particles(target, ParticleTypes.SOUL_FIRE_FLAME, 16);
    }

    public static void legendary(LivingEntity target, LivingEntity attacker) {
        if (target.level() instanceof ServerLevel server) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(server);
            if (bolt != null) {
                bolt.moveTo(target.getX(), target.getY(), target.getZ());
                bolt.setVisualOnly(true);
                server.addFreshEntity(bolt);
            }
        }
        target.setSecondsOnFire(5);
        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
        attacker.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 100, 0));
        particles(target, ParticleTypes.TOTEM_OF_UNDYING, 20);
    }
}
