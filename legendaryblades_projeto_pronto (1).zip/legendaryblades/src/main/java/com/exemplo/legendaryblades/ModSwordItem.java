package com.exemplo.legendaryblades;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ModSwordItem extends SwordItem {

    @FunctionalInterface
    public interface HitEffect {
        void apply(LivingEntity target, LivingEntity attacker);
    }

    private final String id;
    private final boolean foil;
    private final HitEffect effect;

    public ModSwordItem(String id, Tier tier, float attackSpeed, Rarity rarity,
                        boolean foil, boolean fireproof, HitEffect effect) {
        super(tier, 3, attackSpeed, props(rarity, fireproof));
        this.id = id;
        this.foil = foil;
        this.effect = effect;
    }

    private static Item.Properties props(Rarity rarity, boolean fireproof) {
        Item.Properties p = new Item.Properties().rarity(rarity);
        return fireproof ? p.fireResistant() : p;
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (effect != null) effect.apply(target, attacker);
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return foil || super.isFoil(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        if (effect != null) {
            tooltip.add(Component.translatable("tooltip." + LegendaryBlades.MODID + "." + id)
                    .withStyle(ChatFormatting.GOLD));
        }
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
