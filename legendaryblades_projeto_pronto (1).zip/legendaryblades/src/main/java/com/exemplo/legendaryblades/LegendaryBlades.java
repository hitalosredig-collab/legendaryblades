package com.exemplo.legendaryblades;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

@Mod(LegendaryBlades.MODID)
public class LegendaryBlades {
    public static final String MODID = "legendaryblades";

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    // Ordem na aba criativa: tipo por tipo (katana em cima) e, em cada tipo, madeira -> netherite
    private static final String[] ORDER = {"wooden_katana","stone_katana","iron_katana","golden_katana","diamond_katana","netherite_katana","emerald_katana","amethyst_katana","fire_katana","frost_katana","shadow_katana","lunar_katana","wooden_scythe","stone_scythe","iron_scythe","golden_scythe","diamond_scythe","netherite_scythe","emerald_scythe","reaper_scythe","wooden_dagger","stone_dagger","iron_dagger","golden_dagger","diamond_dagger","netherite_dagger","poison_dagger","umbral_dagger","wooden_rapier","stone_rapier","iron_rapier","golden_rapier","diamond_rapier","netherite_rapier","storm_rapier","wooden_slim_sword","stone_slim_sword","iron_slim_sword","golden_slim_sword","diamond_slim_sword","netherite_slim_sword","frostbound_slim_sword","wooden_ancient_sword","stone_ancient_sword","iron_ancient_sword","golden_ancient_sword","diamond_ancient_sword","netherite_ancient_sword","sovereign_ancient_sword","wooden_scimitar","stone_scimitar","iron_scimitar","golden_scimitar","diamond_scimitar","netherite_scimitar","inferno_scimitar","wooden_gladius","stone_gladius","iron_gladius","golden_gladius","diamond_gladius","netherite_gladius","imperial_gladius","wooden_serrated_sword","stone_serrated_sword","iron_serrated_sword","golden_serrated_sword","diamond_serrated_sword","netherite_serrated_sword","dragonfang_sword","wooden_greatsword","stone_greatsword","iron_greatsword","golden_greatsword","diamond_greatsword","netherite_greatsword","titan_greatsword","copper_sword","emerald_sword","obsidian_sword","quartz_sword","frost_blade","twilight_blade","thunder_blade","celestial_blade","void_blade","legendary_sword"};

    public static final RegistryObject<CreativeModeTab> BLADES_TAB = TABS.register("blades",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MODID))
                    .icon(() -> new ItemStack(ModItems.LEGENDARY_SWORD.get()))
                    .displayItems((params, output) -> {
                        for (String id : ORDER) {
                            for (RegistryObject<Item> ro : ModItems.ITEMS.getEntries()) {
                                if (ro.getId().getPath().equals(id)) {
                                    output.accept(ro.get());
                                }
                            }
                        }
                    })
                    .build());

    public LegendaryBlades() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        TABS.register(bus);
    }
}
