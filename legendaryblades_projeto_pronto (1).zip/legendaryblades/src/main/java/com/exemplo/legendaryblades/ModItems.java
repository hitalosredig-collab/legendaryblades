package com.exemplo.legendaryblades;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, LegendaryBlades.MODID);

    // id, tier(durabilidade, dano total, encantamento, reparo), velocidade, raridade, brilho, anti-fogo, efeito
    public static final RegistryObject<Item> EMERALD_KATANA = ITEMS.register("emerald_katana",
            () -> new ModSwordItem("emerald_katana",
                    new SwordTier(1700, 13F, 22, () -> Ingredient.of(Items.EMERALD)),
                    -1.4F, Rarity.UNCOMMON, false, false, SwordEffects::emerald));

    public static final RegistryObject<Item> AMETHYST_KATANA = ITEMS.register("amethyst_katana",
            () -> new ModSwordItem("amethyst_katana",
                    new SwordTier(1500, 12F, 22, () -> Ingredient.of(Items.AMETHYST_SHARD)),
                    -1.4F, Rarity.RARE, false, false, SwordEffects::amethyst));

    public static final RegistryObject<Item> FROST_BLADE = ITEMS.register("frost_blade",
            () -> new ModSwordItem("frost_blade",
                    new SwordTier(980, 14F, 20, () -> Ingredient.of(Items.BLUE_ICE)),
                    -2.6F, Rarity.RARE, false, false, SwordEffects::frost));

    public static final RegistryObject<Item> TWILIGHT_BLADE = ITEMS.register("twilight_blade",
            () -> new ModSwordItem("twilight_blade",
                    new SwordTier(2500, 15F, 18, () -> Ingredient.of(Items.DIAMOND)),
                    -2.6F, Rarity.EPIC, true, true, SwordEffects::twilight));

    public static final RegistryObject<Item> THUNDER_BLADE = ITEMS.register("thunder_blade",
            () -> new ModSwordItem("thunder_blade",
                    new SwordTier(2200, 16F, 20, () -> Ingredient.of(Items.DIAMOND)),
                    -2.6F, Rarity.EPIC, true, false, SwordEffects::thunder));

    // --- Lendarias: mais de 50 de dano, receita muito dificil ---
    public static final RegistryObject<Item> CELESTIAL_BLADE = ITEMS.register("celestial_blade",
            () -> new ModSwordItem("celestial_blade",
                    new SwordTier(4000, 52F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -3.0F, Rarity.EPIC, true, true, SwordEffects::celestial));

    public static final RegistryObject<Item> VOID_BLADE = ITEMS.register("void_blade",
            () -> new ModSwordItem("void_blade",
                    new SwordTier(6000, 66F, 25, () -> Ingredient.of(Items.NETHER_STAR)),
                    -3.2F, Rarity.EPIC, true, true, SwordEffects::voidBlade));

    // --- A espada lendaria principal ---
    public static final RegistryObject<Item> LEGENDARY_SWORD = ITEMS.register("legendary_sword",
            () -> new ModSwordItem("legendary_sword",
                    new SwordTier(5000, 130F, 25, () -> Ingredient.of(Items.NETHERITE_INGOT)),
                    -3.3F, Rarity.EPIC, true, true, SwordEffects::legendary));

    // --- Espadas "estilo vanilla" (sem efeito especial) ---
    public static final RegistryObject<Item> COPPER_SWORD = ITEMS.register("copper_sword",
            () -> new ModSwordItem("copper_sword",
                    new SwordTier(250, 6F, 12, () -> Ingredient.of(Items.COPPER_INGOT)),
                    -2.4F, Rarity.COMMON, false, false, null));

    public static final RegistryObject<Item> EMERALD_SWORD = ITEMS.register("emerald_sword",
            () -> new ModSwordItem("emerald_sword",
                    new SwordTier(1200, 8F, 20, () -> Ingredient.of(Items.EMERALD)),
                    -2.4F, Rarity.UNCOMMON, false, false, null));

    public static final RegistryObject<Item> OBSIDIAN_SWORD = ITEMS.register("obsidian_sword",
            () -> new ModSwordItem("obsidian_sword",
                    new SwordTier(4200, 35F, 10, () -> Ingredient.of(Items.OBSIDIAN)),
                    -2.8F, Rarity.RARE, false, false, null));

    public static final RegistryObject<Item> QUARTZ_SWORD = ITEMS.register("quartz_sword",
            () -> new ModSwordItem("quartz_sword",
                    new SwordTier(800, 7F, 18, () -> Ingredient.of(Items.QUARTZ)),
                    -2.4F, Rarity.COMMON, false, false, null));
}
