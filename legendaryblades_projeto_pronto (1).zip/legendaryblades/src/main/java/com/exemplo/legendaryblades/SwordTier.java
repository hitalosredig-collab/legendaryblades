package com.exemplo.legendaryblades;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

public class SwordTier implements Tier {
    private final int uses;
    private final float damageBonus;
    private final int enchantValue;
    private final Supplier<Ingredient> repair;

    /** totalDamage = dano que aparece no tooltip (ja contando o 1 base do jogador). */
    public SwordTier(int uses, float totalDamage, int enchantValue, Supplier<Ingredient> repair) {
        this.uses = uses;
        this.damageBonus = totalDamage - 4.0F; // 1 (base) + 3 (espada) + bonus do tier
        this.enchantValue = enchantValue;
        this.repair = repair;
    }

    @Override public int getUses() { return uses; }
    @Override public float getSpeed() { return 8.0F; }
    @Override public float getAttackDamageBonus() { return damageBonus; }
    @Override public int getLevel() { return 4; }
    @Override public int getEnchantmentValue() { return enchantValue; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
}
