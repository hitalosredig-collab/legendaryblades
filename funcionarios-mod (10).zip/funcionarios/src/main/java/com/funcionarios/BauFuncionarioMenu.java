package com.funcionarios;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Slots: 0-4 pedidos (o funcionário pega), 5-31 armazenamento, 32-58 inventário do jogador, 59-67 hotbar. */
public class BauFuncionarioMenu extends AbstractContainerMenu {
    public static final int PEDIDOS_X = 43;
    public static final int PEDIDOS_Y = 24;
    public static final int ARMAZEM_X = 8;
    public static final int ARMAZEM_Y = 52;
    public static final int INV_Y = 122;
    public static final int HOT_Y = 180;
    private static final int FIM_BAU = 32;
    private static final int FIM_TUDO = 68;

    private final Container armazem;
    private final Container pedidos;
    private final BlockPos pos;

    /** Cliente: o conteúdo chega pela sincronização do menu. */
    public BauFuncionarioMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, new SimpleContainer(BauFuncionarioBE.ARMAZEM), new SimpleContainer(BauFuncionarioBE.PEDIDOS), buf.readBlockPos());
    }

    public BauFuncionarioMenu(int id, Inventory inv, Container armazem, Container pedidos, BlockPos pos) {
        super(Registros.MENU_BAU.get(), id);
        this.armazem = armazem;
        this.pedidos = pedidos;
        this.pos = pos;
        for (int i = 0; i < BauFuncionarioBE.PEDIDOS; i++) {
            this.addSlot(new Slot(pedidos, i, PEDIDOS_X + i * 18, PEDIDOS_Y));
        }
        for (int linha = 0; linha < 3; linha++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(armazem, col + linha * 9, ARMAZEM_X + col * 18, ARMAZEM_Y + linha * 18));
            }
        }
        for (int linha = 0; linha < 3; linha++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inv, col + linha * 9 + 9, ARMAZEM_X + col * 18, INV_Y + linha * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inv, col, ARMAZEM_X + col * 18, HOT_Y));
        }
    }

    @Override
    public boolean stillValid(Player jogador) {
        return jogador.distanceToSqr(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) <= 64.0D;
    }

    @Override
    public ItemStack quickMoveStack(Player jogador, int indice) {
        ItemStack copia = ItemStack.EMPTY;
        Slot slot = this.slots.get(indice);
        if (slot != null && slot.hasItem()) {
            ItemStack pilha = slot.getItem();
            copia = pilha.copy();
            if (indice < FIM_BAU) {
                if (!this.moveItemStackTo(pilha, FIM_BAU, FIM_TUDO, true)) return ItemStack.EMPTY;
            } else if (!this.moveItemStackTo(pilha, BauFuncionarioBE.PEDIDOS, FIM_BAU, false)) {
                return ItemStack.EMPTY;
            }
            if (pilha.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        return copia;
    }
}
