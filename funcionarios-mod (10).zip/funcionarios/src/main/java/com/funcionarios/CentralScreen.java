package com.funcionarios;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;

/** Central dos funcionários: vida, tarefa, o que ele tem na mão e no inventário; chamar de volta ou parar. */
public class CentralScreen extends Screen {
    private static final int LARGURA = 300;
    private static final int LINHA = 46;
    private static final int TOPO = 28;
    private static final int MAX_LINHAS = 5;

    private List<PacoteLista.Entrada> lista = new ArrayList<>();
    private int tempo;
    private int rolagem;
    private boolean recebeu;

    public CentralScreen() {
        super(Component.literal("Central dos Funcionários"));
    }

    @Override
    protected void init() {
        Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.PEDIR, 0));
        montar();
    }

    public void atualizar(List<PacoteLista.Entrada> nova) {
        this.lista = nova;
        this.recebeu = true;
        this.rolagem = Mth.clamp(rolagem, 0, Math.max(0, lista.size() - MAX_LINHAS));
        montar();
    }

    private int visiveis() {
        return Math.max(1, Math.min(MAX_LINHAS, lista.size() - rolagem));
    }

    private int altura() {
        return TOPO + visiveis() * LINHA + 14;
    }

    private void montar() {
        this.clearWidgets();
        int x = (this.width - LARGURA) / 2;
        int y = (this.height - altura()) / 2;
        for (int k = 0; k < visiveis() && rolagem + k < lista.size(); k++) {
            PacoteLista.Entrada e = lista.get(rolagem + k);
            int ly = y + TOPO + k * LINHA;
            this.addRenderableWidget(Button.builder(Component.literal("Chamar"),
                            b -> Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.CHAMAR, e.id)))
                    .bounds(x + LARGURA - 112, ly + 3, 54, 18).build());
            this.addRenderableWidget(Button.builder(Component.literal("Parar"),
                            b -> Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.PARAR, e.id)))
                    .bounds(x + LARGURA - 54, ly + 3, 48, 18).build());
        }
    }

    @Override
    public void tick() {
        if (++tempo % 40 == 0) {
            Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.PEDIR, 0));
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (lista.size() > MAX_LINHAS) {
            rolagem = Mth.clamp(rolagem - (int) Math.signum(delta), 0, lista.size() - MAX_LINHAS);
            montar();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private ItemStack icone(GuiGraphics g, ItemStack s, int ix, int iy, int mouseX, int mouseY, ItemStack hover) {
        g.fill(ix - 1, iy - 1, ix + 17, iy + 17, 0xFF1E1E1E);
        if (s.isEmpty()) return hover;
        g.renderItem(s, ix, iy);
        g.renderItemDecorations(this.font, s, ix, iy);
        if (mouseX >= ix && mouseX < ix + 16 && mouseY >= iy && mouseY < iy + 16) return s;
        return hover;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float parcial) {
        this.renderBackground(g);
        int x = (this.width - LARGURA) / 2;
        int y = (this.height - altura()) / 2;
        g.fill(x - 1, y - 1, x + LARGURA + 1, y + altura() + 1, 0xFF000000);
        g.fill(x, y, x + LARGURA, y + altura(), 0xFF2B2B2B);
        g.drawCenteredString(this.font, this.title, this.width / 2, y + 9, 0xFFD700);

        if (lista.isEmpty()) {
            String msg = recebeu ? "Nenhum funcionário em área carregada." : "Carregando...";
            g.drawCenteredString(this.font, Component.literal(msg), this.width / 2, y + TOPO + 9, 0xAAAAAA);
        }

        ItemStack hover = ItemStack.EMPTY;
        for (int k = 0; k < visiveis() && rolagem + k < lista.size(); k++) {
            PacoteLista.Entrada e = lista.get(rolagem + k);
            int ly = y + TOPO + k * LINHA;
            g.fill(x + 4, ly, x + LARGURA - 4, ly + LINHA - 2, 0xFF3C3C3C);

            g.drawString(this.font, Component.literal(e.nome), x + 8, ly + 4, 0xFFD700, false);
            g.drawString(this.font, Component.literal(Tarefa.de(e.tarefa).getRotulo()), x + 8, ly + 15, 0xFFFFFF, false);

            // vida (barra + número)
            float prop = e.vidaMax <= 0 ? 0 : Mth.clamp(e.vida / e.vidaMax, 0.0F, 1.0F);
            int cor = prop > 0.5F ? 0xFF3DBE4A : (prop > 0.25F ? 0xFFE0B020 : 0xFFD03030);
            g.drawString(this.font, Component.literal("Vida " + (int) e.vida + "/" + (int) e.vidaMax), x + 110, ly + 4, 0xDDDDDD, false);
            g.fill(x + 110, ly + 15, x + 180, ly + 22, 0xFF000000);
            g.fill(x + 111, ly + 16, x + 111 + (int) (68 * prop), ly + 21, cor);

            // mão e inventário
            g.drawString(this.font, Component.literal("Mão"), x + 8, ly + 29, 0xAAAAAA, false);
            hover = icone(g, e.mao, x + 30, ly + 25, mouseX, mouseY, hover);
            int ix = x + 54;
            for (ItemStack s : e.itens) {
                hover = icone(g, s, ix, ly + 25, mouseX, mouseY, hover);
                ix += 18;
            }
            if (e.itens.isEmpty()) {
                g.drawString(this.font, Component.literal("inventário vazio"), ix, ly + 29, 0x888888, false);
            }
            g.drawString(this.font, Component.literal(e.distancia + " blocos"), x + LARGURA - 58, ly + 29, 0xAAAAAA, false);
        }
        if (lista.size() > MAX_LINHAS) {
            g.drawCenteredString(this.font, Component.literal("Role o mouse para ver os outros (" + lista.size() + ")"),
                    this.width / 2, y + altura() - 11, 0x888888);
        }
        super.render(g, mouseX, mouseY, parcial);
        if (!hover.isEmpty()) {
            g.renderTooltip(this.font, hover, mouseX, mouseY);
        }
    }
}
