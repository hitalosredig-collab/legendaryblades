package com.funcionarios;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class Registros {
    public static final DeferredRegister<EntityType<?>> ENTIDADES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, FuncionariosMod.MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, FuncionariosMod.MOD_ID);
    public static final DeferredRegister<Block> BLOCOS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, FuncionariosMod.MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCOS_ENTIDADE =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, FuncionariosMod.MOD_ID);
    public static final DeferredRegister<Item> ITENS =
            DeferredRegister.create(ForgeRegistries.ITEMS, FuncionariosMod.MOD_ID);

    public static final RegistryObject<EntityType<FuncionarioEntity>> FUNCIONARIO =
            ENTIDADES.register("funcionario", () ->
                    EntityType.Builder.of(FuncionarioEntity::new, MobCategory.CREATURE)
                            .sized(0.6F, 1.8F)
                            .clientTrackingRange(10)
                            .build("funcionario"));

    public static final RegistryObject<MenuType<FuncionarioMenu>> MENU =
            MENUS.register("funcionario", () -> IForgeMenuType.create(FuncionarioMenu::new));

    public static final RegistryObject<Item> CONTRATO =
            ITENS.register("contrato", () -> new ContratoItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Block> BAU = BLOCOS.register("bau_funcionario", () ->
            new BauFuncionarioBloco(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD)
                    .strength(2.5F).sound(SoundType.WOOD)));

    public static final RegistryObject<Item> BAU_ITEM =
            ITENS.register("bau_funcionario", () -> new BlockItem(BAU.get(), new Item.Properties()));

    public static final RegistryObject<BlockEntityType<BauFuncionarioBE>> BAU_BE =
            BLOCOS_ENTIDADE.register("bau_funcionario", () ->
                    BlockEntityType.Builder.of(BauFuncionarioBE::new, BAU.get()).build(null));

    public static final RegistryObject<MenuType<BauFuncionarioMenu>> MENU_BAU =
            MENUS.register("bau_funcionario", () -> IForgeMenuType.create(BauFuncionarioMenu::new));

    public static final RegistryObject<Item> CENTRAL =
            ITENS.register("central", () -> new CentralItem(new Item.Properties().stacksTo(1)));}
