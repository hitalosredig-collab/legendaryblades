package com.funcionarios;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/** Tela do Baú do Funcionário (176 de largura, pequena para não brigar com JEI). */
public class BauFuncionarioScreen extends AbstractContainerScreen<BauFuncionarioMenu> {
    public BauFuncionarioScreen(BauFuncionarioMenu menu, Inventory inventario, Component titulo) {
        super(menu, inventario, titulo);
        this.imageWidth = 176;
        this.imageHeight = 202;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float parcial) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, parcial);
        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawCenteredString(this.font, Component.literal("Para o funcionário pegar"), this.imageWidth / 2, 7, 0x1B5E20);
        g.drawString(this.font, Component.literal("Guardado"), 8, 42, 0x404040, false);
        g.drawString(this.font, this.playerInventoryTitle, 8, BauFuncionarioMenu.INV_Y - 11, 0x404040, false);
    }

    @Override
    protected void renderBg(GuiGraphics g, float parcial, int mouseX, int mouseY) {
        g.fill(this.leftPos - 1, this.topPos - 1, this.leftPos + this.imageWidth + 1, this.topPos + this.imageHeight + 1, 0xFF000000);
        g.fill(this.leftPos, this.topPos, this.leftPos + this.imageWidth, this.topPos + this.imageHeight, 0xFFC6C6C6);
        // faixa verde atrás dos 5 slots de pedido
        g.fill(this.leftPos + BauFuncionarioMenu.PEDIDOS_X - 4, this.topPos + BauFuncionarioMenu.PEDIDOS_Y - 4,
                this.leftPos + BauFuncionarioMenu.PEDIDOS_X + 5 * 18 + 2, this.topPos + BauFuncionarioMenu.PEDIDOS_Y + 20, 0xFF66BB6A);
        for (int i = 0; i < this.menu.slots.size(); i++) {
            Slot s = this.menu.slots.get(i);
            int sx = this.leftPos + s.x;
            int sy = this.topPos + s.y;
            g.fill(sx - 1, sy - 1, sx + 17, sy + 17, i < BauFuncionarioBE.PEDIDOS ? 0xFF1B5E20 : 0xFF373737);
            g.fill(sx, sy, sx + 17, sy + 17, 0xFFFFFFFF);
            g.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
        }
    }
}
