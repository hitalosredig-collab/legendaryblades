package com.funcionarios;

import com.mojang.logging.LogUtils;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import org.slf4j.Logger;

/**
 * Vozes com variedade no Windows.
 *
 * O sintetizador do sistema (System.Speech) grava a fala num arquivo de áudio e o mod muda o tom antes de tocar
 * (voz grave de homem, voz mais fina de mulher, e variações por personalidade). Assim, mesmo com UMA voz instalada,
 * dá para ter vozes bem diferentes. Se o Windows tiver vozes masculinas e femininas em português, elas são usadas
 * conforme o gênero e o tom só varia de leve. Em outros sistemas, ou se algo falhar, o mod usa o narrador comum.
 */
public final class VozWindows {
    private static final Logger LOG = LogUtils.getLogger();

    private static final String SCRIPT = """
            Add-Type -AssemblyName System.Speech
            $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
            $todas = @($s.GetInstalledVoices() | Where-Object { $_.Enabled } | ForEach-Object { $_.VoiceInfo })
            $pt = @($todas | Where-Object { $_.Culture.Name -like 'pt*' })
            if ($pt.Count -gt 0) { $todas = $pt }
            [Console]::InputEncoding = [Text.Encoding]::UTF8
            while (($linha = [Console]::In.ReadLine()) -ne $null) {
              $desencontro = 1
              try {
                $p = $linha.Split('|')
                $quer = 'Male'; if ($p[0] -eq '1') { $quer = 'Female' }
                $mesmo = @($todas | Where-Object { $_.Gender.ToString() -eq $quer })
                if ($mesmo.Count -gt 0) { $voz = $mesmo[[int]$p[1] % $mesmo.Count]; $desencontro = 0 }
                else { $voz = $todas[[int]$p[1] % $todas.Count] }
                $texto = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($p[2]))
                $s.SelectVoice($voz.Name)
                $s.SetOutputToWaveFile($p[3])
                $s.Speak($texto)
                $s.SetOutputToNull()
              } catch { }
              [Console]::Out.WriteLine('OK|' + $desencontro)
              [Console]::Out.Flush()
            }
            """;

    private static final ExecutorService FILA = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "funcionarios-voz");
        t.setDaemon(true);
        return t;
    });
    private static final AtomicBoolean OCUPADO = new AtomicBoolean();

    private static Process processo;
    private static BufferedWriter escritor;
    private static BufferedReader leitor;
    private static volatile boolean falhou;
    private static int partidas;
    private static int falhasSeguidas;

    private VozWindows() {}

    public static boolean disponivel() {
        return !falhou && System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    /**
     * Fala em segundo plano. genero: 0 masculino, 1 feminino. indice escolhe entre vozes do mesmo gênero.
     * fatorTom: 1,0 = voz original; menor = mais grave (e mais lenta); maior = mais aguda.
     * Devolve false se não deu para usar (aí o chamador cai no narrador comum).
     */
    public static boolean falar(String texto, int genero, int indice, float fatorTom) {
        if (!disponivel()) return false;
        if (!OCUPADO.compareAndSet(false, true)) return true; // ainda falando: não atropela
        FILA.execute(() -> {
            try {
                executar(texto, genero, indice, fatorTom);
                falhasSeguidas = 0;
            } catch (Exception e) {
                LOG.warn("[Funcionarios] Falha na voz do Windows.", e);
                if (++falhasSeguidas >= 3) {
                    falhou = true;
                    LOG.warn("[Funcionarios] Voz do Windows desativada; usando o narrador comum.");
                }
                if (processo != null) processo.destroy();
            } finally {
                OCUPADO.set(false);
            }
        });
        return true;
    }

    private static void garantir() throws IOException {
        if (processo != null && processo.isAlive()) return;
        if (++partidas > 4) {
            throw new IOException("PowerShell de voz caiu várias vezes");
        }
        String codificado = Base64.getEncoder().encodeToString(SCRIPT.getBytes(StandardCharsets.UTF_16LE));
        ProcessBuilder pb = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive",
                "-ExecutionPolicy", "Bypass", "-EncodedCommand", codificado);
        pb.redirectErrorStream(true);
        processo = pb.start();
        escritor = new BufferedWriter(new OutputStreamWriter(processo.getOutputStream(), StandardCharsets.UTF_8));
        leitor = new BufferedReader(new InputStreamReader(processo.getInputStream(), StandardCharsets.UTF_8));
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (processo != null) processo.destroy();
        }));
    }

    private static void executar(String texto, int genero, int indice, float fatorTom) throws Exception {
        garantir();
        Path wav = Files.createTempFile("funcionarios-voz", ".wav");
        try {
            String b64 = Base64.getEncoder().encodeToString(texto.getBytes(StandardCharsets.UTF_8));
            String caminho = wav.toAbsolutePath().toString().replace("|", "");
            escritor.write((genero == 1 ? "1" : "0") + "|" + Math.abs(indice) + "|" + b64 + "|" + caminho + "\n");
            escritor.flush();
            String resposta = lerResposta(20000);
            if (resposta == null) throw new IOException("o sintetizador não respondeu");
            boolean desencontro = resposta.endsWith("|1"); // não há voz do gênero pedido: o tom faz a diferença toda
            float fator = desencontro ? fatorTom : 1.0F + (fatorTom - 1.0F) * 0.4F;
            tocar(wav, fator);
        } finally {
            Files.deleteIfExists(wav);
        }
    }

    private static String lerResposta(long limiteMs) throws IOException, InterruptedException {
        long fim = System.currentTimeMillis() + limiteMs;
        while (System.currentTimeMillis() < fim) {
            if (leitor.ready()) {
                String linha = leitor.readLine();
                if (linha == null) return null;
                if (linha.startsWith("OK|")) return linha;
            } else {
                Thread.sleep(15);
            }
        }
        return null;
    }

    private static void tocar(Path wav, float fator) throws Exception {
        try (AudioInputStream entrada = AudioSystem.getAudioInputStream(wav.toFile())) {
            AudioFormat formato = entrada.getFormat();
            byte[] dados = entrada.readAllBytes();
            if (dados.length == 0) throw new IOException("áudio vazio");
            boolean pcm16 = formato.getSampleSizeInBits() == 16
                    && formato.getEncoding() == AudioFormat.Encoding.PCM_SIGNED && !formato.isBigEndian();
            if (pcm16 && Math.abs(fator - 1.0F) > 0.01F) {
                dados = reamostrar(dados, formato.getChannels(), fator);
            }
            try (SourceDataLine linha = AudioSystem.getSourceDataLine(formato)) {
                linha.open(formato);
                linha.start();
                linha.write(dados, 0, dados.length);
                linha.drain();
            }
        }
    }

    /** Muda o tom por reamostragem linear: fator > 1 = mais agudo e mais rápido; fator < 1 = mais grave e mais lento. */
    private static byte[] reamostrar(byte[] dados, int canais, float fator) {
        int quadros = dados.length / (2 * canais);
        int novos = Math.max(1, (int) (quadros / fator));
        byte[] saida = new byte[novos * 2 * canais];
        for (int i = 0; i < novos; i++) {
            double pos = i * (double) fator;
            int i0 = Math.min((int) pos, quadros - 1);
            int i1 = Math.min(i0 + 1, quadros - 1);
            double frac = pos - i0;
            for (int c = 0; c < canais; c++) {
                int a = amostra(dados, i0 * canais + c);
                int b = amostra(dados, i1 * canais + c);
                int v = (int) Math.round(a + (b - a) * frac);
                int destino = (i * canais + c) * 2;
                saida[destino] = (byte) (v & 0xFF);
                saida[destino + 1] = (byte) ((v >> 8) & 0xFF);
            }
        }
        return saida;
    }

    private static int amostra(byte[] dados, int indice) {
        int baixo = dados[indice * 2] & 0xFF;
        int alto = dados[indice * 2 + 1]; // com sinal
        return (alto << 8) | baixo;
    }
}
