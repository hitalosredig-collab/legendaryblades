package com.funcionarios;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkHooks;

/** Baú só para os funcionários: eles guardam o que coletam aqui e pegam o que você deixou nos 5 slots de pedido. */
public class BauFuncionarioBloco extends BaseEntityBlock {
    public BauFuncionarioBloco(Properties propriedades) {
        super(propriedades);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState estado) {
        return new BauFuncionarioBE(pos, estado);
    }

    @Override
    public RenderShape getRenderShape(BlockState estado) {
        return RenderShape.MODEL;
    }

    @Override
    public InteractionResult use(BlockState estado, Level nivel, BlockPos pos, Player jogador,
                                 InteractionHand mao, BlockHitResult acerto) {
        if (nivel.isClientSide) return InteractionResult.SUCCESS;
        BlockEntity be = nivel.getBlockEntity(pos);
        if (be instanceof BauFuncionarioBE bau && jogador instanceof ServerPlayer sp) {
            if (bau.getDono() != null && !bau.getDono().equals(jogador.getUUID()) && !jogador.isCreative()) {
                sp.displayClientMessage(Component.literal("Este baú é de outro jogador."), true);
                return InteractionResult.CONSUME;
            }
            NetworkHooks.openScreen(sp, new SimpleMenuProvider(
                    (id, inv, p) -> new BauFuncionarioMenu(id, inv, bau.getArmazem(), bau.getPedidos(), pos),
                    Component.literal("Baú do Funcionário")), buf -> buf.writeBlockPos(pos));
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void setPlacedBy(Level nivel, BlockPos pos, BlockState estado, LivingEntity quem, ItemStack pilha) {
        super.setPlacedBy(nivel, pos, estado, quem, pilha);
        if (!nivel.isClientSide && quem instanceof Player jogador
                && nivel.getBlockEntity(pos) instanceof BauFuncionarioBE bau) {
            bau.setDono(jogador.getUUID());
        }
    }

    @Override
    public void onRemove(BlockState estado, Level nivel, BlockPos pos, BlockState novo, boolean movido) {
        if (!estado.is(novo.getBlock()) && nivel.getBlockEntity(pos) instanceof BauFuncionarioBE bau) {
            Containers.dropContents(nivel, pos, bau.getArmazem());
            Containers.dropContents(nivel, pos, bau.getPedidos());
        }
        super.onRemove(estado, nivel, pos, novo, movido);
    }
}
