package com.funcionarios;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

/** Cliente -> servidor: pedidos da tela da Central (atualizar lista, chamar de volta, parar). */
public class PacoteCentral {
    public static final int PEDIR = 0;
    public static final int CHAMAR = 1;
    public static final int PARAR = 2;
    private static final int MAXIMO = 10;

    private final int acao;
    private final int entidade;

    public PacoteCentral(int acao, int entidade) {
        this.acao = acao;
        this.entidade = entidade;
    }

    public void codificar(FriendlyByteBuf buf) {
        buf.writeInt(acao);
        buf.writeInt(entidade);
    }

    public static PacoteCentral decodificar(FriendlyByteBuf buf) {
        return new PacoteCentral(buf.readInt(), buf.readInt());
    }

    /** O que ele carrega no inventário, somando itens iguais (até 9 tipos). */
    private static List<ItemStack> resumo(FuncionarioEntity f) {
        List<ItemStack> r = new ArrayList<>();
        SimpleContainer inv = f.getInventario();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) continue;
            boolean achou = false;
            for (ItemStack x : r) {
                if (ItemStack.isSameItemSameTags(x, s)) {
                    x.grow(s.getCount());
                    achou = true;
                    break;
                }
            }
            if (!achou && r.size() < 9) r.add(s.copy());
        }
        return r;
    }

    public static void tratar(PacoteCentral pacote, Supplier<NetworkEvent.Context> contexto) {
        contexto.get().enqueueWork(() -> {
            ServerPlayer jogador = contexto.get().getSender();
            if (jogador == null) return;

            if (pacote.acao != PEDIR) {
                Entity e = jogador.serverLevel().getEntity(pacote.entidade);
                if (e instanceof FuncionarioEntity f && f.ehDono(jogador)) {
                    if (pacote.acao == CHAMAR) {
                        f.chamarDeVolta(jogador);
                    } else if (pacote.acao == PARAR) {
                        f.receberComando(Tarefa.PARAR, jogador);
                    }
                }
            }

            List<PacoteLista.Entrada> lista = new ArrayList<>();
            for (Entity e : jogador.serverLevel().getAllEntities()) {
                if (lista.size() >= MAXIMO) break;
                if (e instanceof FuncionarioEntity f && f.ehDono(jogador)) {
                    lista.add(new PacoteLista.Entrada(f.getId(), f.getName().getString(),
                            f.getTarefa().ordinal(), f.getHealth(), f.getMaxHealth(),
                            (int) Math.sqrt(f.distanceToSqr(jogador)), f.getMainHandItem().copy(), resumo(f)));
                }
            }
            Rede.CANAL.send(PacketDistributor.PLAYER.with(() -> jogador), new PacoteLista(lista));
        });
        contexto.get().setPacketHandled(true);
    }
}
