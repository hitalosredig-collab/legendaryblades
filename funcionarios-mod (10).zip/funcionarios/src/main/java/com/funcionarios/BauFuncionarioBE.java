package com.funcionarios;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.wrapper.InvWrapper;

/**
 * Baú do Funcionário: 27 slots de armazenamento (onde ele guarda o que coleta) e 5 slots de "pedidos"
 * (o que o jogador deixa para ele pegar: armadura, ferramentas, escudo, comida...).
 */
public class BauFuncionarioBE extends BlockEntity {
    /** Todos os baús carregados no servidor (para o funcionário achar o do dono sem varrer o mundo). */
    public static final Set<BauFuncionarioBE> TODOS = ConcurrentHashMap.newKeySet();

    public static final int ARMAZEM = 27;
    public static final int PEDIDOS = 5;

    private final SimpleContainer armazem = new SimpleContainer(ARMAZEM);
    private final SimpleContainer pedidos = new SimpleContainer(PEDIDOS);
    private final LazyOptional<IItemHandler> manipulador = LazyOptional.of(() -> new InvWrapper(armazem));
    private UUID dono;

    public BauFuncionarioBE(BlockPos pos, BlockState estado) {
        super(Registros.BAU_BE.get(), pos, estado);
        armazem.addListener(c -> setChanged());
        pedidos.addListener(c -> setChanged());
    }

    public SimpleContainer getArmazem() {
        return armazem;
    }

    public SimpleContainer getPedidos() {
        return pedidos;
    }

    public UUID getDono() {
        return dono;
    }

    public void setDono(UUID dono) {
        this.dono = dono;
        setChanged();
    }

    public boolean temPedidos() {
        return !pedidos.isEmpty();
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (this.level != null && !this.level.isClientSide) TODOS.add(this);
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        TODOS.remove(this);
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        TODOS.remove(this);
    }

    @Override
    public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction lado) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) return manipulador.cast();
        return super.getCapability(cap, lado);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        manipulador.invalidate();
    }

    private static ListTag salvar(SimpleContainer c) {
        ListTag lista = new ListTag();
        for (int i = 0; i < c.getContainerSize(); i++) {
            ItemStack s = c.getItem(i);
            if (s.isEmpty()) continue;
            CompoundTag t = new CompoundTag();
            t.putByte("Slot", (byte) i);
            s.save(t);
            lista.add(t);
        }
        return lista;
    }

    private static void carregar(SimpleContainer c, ListTag lista) {
        c.clearContent();
        for (int i = 0; i < lista.size(); i++) {
            CompoundTag t = lista.getCompound(i);
            int slot = t.getByte("Slot") & 255;
            if (slot < c.getContainerSize()) c.setItem(slot, ItemStack.of(t));
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Armazem", salvar(armazem));
        tag.put("Pedidos", salvar(pedidos));
        if (dono != null) tag.putUUID("Dono", dono);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        carregar(armazem, tag.getList("Armazem", 10));
        carregar(pedidos, tag.getList("Pedidos", 10));
        dono = tag.hasUUID("Dono") ? tag.getUUID("Dono") : null;
    }
}
