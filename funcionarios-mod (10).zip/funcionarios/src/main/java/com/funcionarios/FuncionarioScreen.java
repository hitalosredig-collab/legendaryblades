package com.funcionarios;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Janela compacta (176 x 216, do tamanho de um baú duplo) para não brigar com mods de itens como o JEI.
 * Duas abas na mesma janela: "Itens" (equipamento, ferramentas, inventários) e "Comandos".
 */
public class FuncionarioScreen extends AbstractContainerScreen<FuncionarioMenu> {
    private static final int LARGURA_COL = 80;
    private static final int ALTURA_BOTAO = 18;

    /** Ícone "fantasma" mostrado nos slots de arma/ferramenta vazios. */
    private static final Item[] FANTASMAS = {
            Items.IRON_SWORD, Items.IRON_SWORD, Items.IRON_PICKAXE, Items.IRON_AXE, Items.IRON_SHOVEL, Items.IRON_HOE
    };

    private static final Tarefa[] COMANDOS = {
            Tarefa.PARAR, Tarefa.SEGUIR, Tarefa.DEFENDER, Tarefa.ENTREGAR,
            Tarefa.MADEIRA, Tarefa.PEDRA, Tarefa.MINERIO, Tarefa.COLHER
    };
    private static final String[] ROTULOS = {
            "Parar", "Seguir", "Defender", "Entregar", "Madeira", "Pedra", "Minério", "Colher"
    };

    private final List<Button> botoesComandos = new ArrayList<>();
    private Button abaItens;
    private Button abaComandos;
    private Button botaoMinerio;
    private Button botaoVoz;
    private Button botaoMelhorar;
    private int nivelDoBotao = -1;

    public FuncionarioScreen(FuncionarioMenu menu, Inventory inventario, Component titulo) {
        super(menu, inventario, titulo);
        this.imageWidth = 176;
        this.imageHeight = 216;
        this.inventoryLabelX = FuncionarioMenu.INV_X;
        this.inventoryLabelY = FuncionarioMenu.INV_Y - 11;
    }

    private void enviar(Tarefa tarefa) {
        Rede.CANAL.sendToServer(new PacoteComando(this.menu.getFuncionario().getId(), tarefa.ordinal()));
    }

    private Button botao(String texto, int x, int y, int largura, Button.OnPress acao) {
        Button b = Button.builder(Component.literal(texto), acao)
                .bounds(this.leftPos + x, this.topPos + y, largura, ALTURA_BOTAO).build();
        this.addRenderableWidget(b);
        botoesComandos.add(b);
        return b;
    }

    @Override
    protected void init() {
        super.init();
        botoesComandos.clear();

        // abas (no topo da janela)
        abaItens = Button.builder(Component.literal("Itens"), b -> this.menu.abaComandos = false)
                .bounds(this.leftPos + 6, this.topPos + 4, 82, 14).build();
        abaComandos = Button.builder(Component.literal("Comandos"), b -> this.menu.abaComandos = true)
                .bounds(this.leftPos + 88, this.topPos + 4, 82, 14).build();
        this.addRenderableWidget(abaItens);
        this.addRenderableWidget(abaComandos);

        // comandos em duas colunas
        int y = 86;
        int col = 0;
        for (int i = 0; i < COMANDOS.length; i++) {
            Tarefa t = COMANDOS[i];
            if (t == Tarefa.MINERIO) {
                if (col == 1) { col = 0; y += 20; }
                botaoMinerio = botao("Minério", 6, y, 138, b -> enviar(Tarefa.MINERIO));
                botao("<>", 146, y, 22, b -> enviar(Tarefa.TROCAR_MINERIO));
                y += 20;
                continue;
            }
            botao(ROTULOS[i], 6 + col * (LARGURA_COL + 4), y, LARGURA_COL, b -> enviar(t));
            if (++col == 2) { col = 0; y += 20; }
        }
        if (col == 1) y += 20;
        botaoVoz = botao("Voz", 6, y, LARGURA_COL, b -> {
            Configuracao.VOZ_ATIVA.set(!Configuracao.VOZ_ATIVA.get());
            Configuracao.VOZ_ATIVA.save();
        });
        botaoMelhorar = botao("Melhorar", 6 + LARGURA_COL + 4, y, LARGURA_COL, b -> enviar(Tarefa.MELHORAR));
        nivelDoBotao = -1;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float parcial) {
        this.renderBackground(g);
        boolean comandos = this.menu.abaComandos;
        for (Button b : botoesComandos) {
            b.visible = comandos;
        }
        abaItens.active = comandos;
        abaComandos.active = !comandos;

        if (botaoMinerio != null) {
            botaoMinerio.setMessage(Component.literal("Minério: " + this.menu.getFuncionario().getMinerio().getRotulo()));
        }
        if (botaoVoz != null) {
            botaoVoz.setMessage(Component.literal("Voz: " + (Configuracao.VOZ_ATIVA.get() ? "sim" : "não")));
        }
        if (botaoMelhorar != null) {
            int n = this.menu.getFuncionario().getNivel();
            if (n != nivelDoBotao) {
                nivelDoBotao = n;
                if (n >= 3) {
                    botaoMelhorar.setMessage(Component.literal("Máximo 4x4"));
                    botaoMelhorar.active = false;
                    botaoMelhorar.setTooltip(null);
                } else {
                    botaoMelhorar.setMessage(Component.literal("Melhorar " + (n + 2) + "x" + (n + 2)));
                    botaoMelhorar.active = true;
                    botaoMelhorar.setTooltip(Tooltip.create(Component.literal(
                            "Custo: " + FuncionarioEntity.descreverCusto(FuncionarioEntity.custoMelhoria(n)))));
                }
            }
        }
        super.render(g, mouseX, mouseY, parcial);
        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        if (!this.menu.abaComandos) {
            g.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY, 0x404040, false);
        }
    }

    @Override
    protected void renderBg(GuiGraphics g, float parcial, int mouseX, int mouseY) {
        FuncionarioEntity f = this.menu.getFuncionario();

        // janela
        g.fill(this.leftPos - 1, this.topPos - 1, this.leftPos + this.imageWidth + 1, this.topPos + this.imageHeight + 1, 0xFF000000);
        g.fill(this.leftPos, this.topPos, this.leftPos + this.imageWidth, this.topPos + this.imageHeight, 0xFFC6C6C6);

        if (!this.menu.abaComandos) {
            // moldura dos slots
            for (Slot s : this.menu.slots) {
                if (!s.isActive()) continue;
                int sx = this.leftPos + s.x;
                int sy = this.topPos + s.y;
                g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
                g.fill(sx, sy, sx + 17, sy + 17, 0xFFFFFFFF);
                g.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
            }
            // ícones apagados nos slots de arma/ferramenta vazios
            for (int i = 0; i < FANTASMAS.length; i++) {
                Slot s = this.menu.slots.get(FuncionarioMenu.INICIO_FERR + i);
                if (!s.hasItem()) {
                    int sx = this.leftPos + s.x;
                    int sy = this.topPos + s.y;
                    g.renderFakeItem(new ItemStack(FANTASMAS[i]), sx, sy);
                    g.fill(RenderType.guiGhostRecipeOverlay(), sx, sy, sx + 16, sy + 16, 0xB08B8B8B);
                }
            }
            // nome e vida ao lado do equipamento
            g.drawString(this.font, f.getName(), this.leftPos + 102, this.topPos + 23, 0x202020, false);
            g.drawString(this.font, Component.literal("Vida " + (int) f.getHealth() + "/" + (int) f.getMaxHealth()),
                    this.leftPos + 102, this.topPos + 33, 0x802020, false);
            g.drawString(this.font, Component.literal("Nível " + f.getNivel()), this.leftPos + 128, this.topPos + 46, 0x206020, false);
            return;
        }

        // aba de comandos: caixa de status e fala
        int px = this.leftPos + 6;
        int py = this.topPos + 22;
        g.fill(px, py, px + 164, py + 58, 0xFF1E1E1E);
        g.drawString(this.font, f.getName(), px + 4, py + 4, 0xFFD700, false);
        int lado = f.getNivel() + 1;
        g.drawString(this.font, Component.literal("Nível " + f.getNivel() + " (" + lado + "x" + lado + ")"), px + 100, py + 4, 0x8FD18F, false);
        g.drawString(this.font, Component.literal("Tarefa: " + f.getTarefa().getRotulo()), px + 4, py + 15, 0xAAAAAA, false);
        String fala = f.getFala();
        if (fala != null && !fala.isEmpty()) {
            int linhaY = py + 28;
            for (FormattedCharSequence linha : this.font.split(Component.literal(fala), 156)) {
                if (linhaY > py + 48) break;
                g.drawString(this.font, linha, px + 4, linhaY, 0xFFFFFF, false);
                linhaY += 10;
            }
        }
    }
}
